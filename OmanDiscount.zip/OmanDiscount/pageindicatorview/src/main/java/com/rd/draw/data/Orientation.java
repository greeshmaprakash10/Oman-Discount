package com.rd.draw.data;

public enum Orientation {HORIZONTAL, VERTICAL}
