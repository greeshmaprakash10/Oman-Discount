package com.rd.draw.data;

public enum RtlMode {On, Off, Auto}